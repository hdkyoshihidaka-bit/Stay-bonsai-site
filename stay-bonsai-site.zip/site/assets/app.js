(function(){var b=document.querySelector('.burger'),n=document.getElementById('nav');
function tg(o){var s=typeof o=='boolean'?o:!n.classList.contains('open');n.classList.toggle('open',s);b.setAttribute('aria-expanded',s);b.setAttribute('aria-label',s?'Fechar menu':'Abrir menu')}
b.addEventListener('click',function(){tg()});n.addEventListener('click',function(e){if(e.target.tagName=='A')tg(false)});
var r=document.querySelectorAll('.reveal');if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});r.forEach(function(x){io.observe(x)})}else r.forEach(function(x){x.classList.add('in')});
var lb=document.querySelector('.lb'),items=[].slice.call(document.querySelectorAll('.gi')),i=0,last=null;if(!lb)return;
var im=lb.querySelector('img'),cp=lb.querySelector('figcaption');
function show(k){i=(k+items.length)%items.length;var s=items[i].querySelector('img');im.src=items[i].dataset.full;im.alt=s.alt;cp.textContent=(i+1)+' / '+items.length}
function open(k){last=document.activeElement;show(k);lb.hidden=false;document.body.style.overflow='hidden';lb.querySelector('.lb-x').focus()}
function close(){lb.hidden=true;document.body.style.overflow='';if(last)last.focus()}
items.forEach(function(x,k){x.addEventListener('click',function(){open(k)})});
lb.querySelector('.lb-x').onclick=close;lb.querySelector('.lb-p').onclick=function(){show(i-1)};lb.querySelector('.lb-n').onclick=function(){show(i+1)};
lb.addEventListener('click',function(e){if(e.target===lb)close()});
document.addEventListener('keydown',function(e){if(lb.hidden)return;if(e.key=='Escape')close();else if(e.key=='ArrowLeft')show(i-1);else if(e.key=='ArrowRight')show(i+1);else if(e.key=='Tab'){var f=[].slice.call(lb.querySelectorAll('button'));var a=f.indexOf(document.activeElement);e.preventDefault();f[(a+(e.shiftKey?-1:1)+f.length)%f.length].focus()}});
})();